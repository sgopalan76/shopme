"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  MapPin,
  Clock,
  DollarSign,
  Star,
  Phone,
  Mail,
  Globe,
  ArrowLeft,
  Heart,
  MessageSquare,
  Share2,
} from "lucide-react"
import { useNotificationContext } from "@/components/notification-provider"

// Mock data for partners and their services
const partnersData = [
  {
    id: 101,
    businessName: "Scissors & Combs",
    ownerName: "Michael Brown",
    email: "contact@scissorscombs.com",
    phone: "555-222-3333",
    website: "www.scissorscombs.com",
    address: "101 Elm St, Anytown, USA",
    description:
      "We specialize in modern haircuts and styling for all hair types. Our experienced stylists provide personalized service in a relaxing environment.",
    rating: 4.8,
    reviewCount: 124,
    image: "/placeholder.svg?height=300&width=600",
    logo: "/placeholder.svg?height=80&width=80",
    hours: [
      { day: "Monday", hours: "9:00 AM - 7:00 PM" },
      { day: "Tuesday", hours: "9:00 AM - 7:00 PM" },
      { day: "Wednesday", hours: "9:00 AM - 7:00 PM" },
      { day: "Thursday", hours: "9:00 AM - 8:00 PM" },
      { day: "Friday", hours: "9:00 AM - 8:00 PM" },
      { day: "Saturday", hours: "10:00 AM - 6:00 PM" },
      { day: "Sunday", hours: "Closed" },
    ],
    services: [
      {
        id: 1,
        name: "Men's Haircut",
        description: "Professional haircut for men including wash and style.",
        price: 35,
        duration: 30,
      },
      {
        id: 2,
        name: "Women's Haircut",
        description: "Professional haircut for women including wash and style.",
        price: 55,
        duration: 45,
      },
      {
        id: 3,
        name: "Hair Coloring",
        description: "Full hair coloring service with premium products.",
        price: 85,
        duration: 90,
      },
    ],
    reviews: [
      {
        id: 201,
        author: "John D.",
        rating: 5,
        date: "2023-05-15",
        comment: "Great service, very professional and friendly staff.",
      },
      {
        id: 202,
        author: "Sarah M.",
        rating: 4,
        date: "2023-04-22",
        comment: "Love my new haircut! Will definitely be back.",
      },
      {
        id: 203,
        author: "Robert K.",
        rating: 5,
        date: "2023-03-10",
        comment: "Best haircut I've had in years. Highly recommend.",
      },
    ],
  },
  {
    id: 102,
    businessName: "Glamour Zone",
    ownerName: "Emily Wilson",
    email: "info@glamourzone.com",
    phone: "555-444-5555",
    website: "www.glamourzone.com",
    address: "202 Maple Ave, Somewhere, USA",
    description:
      "Glamour Zone offers premium nail care, facials, and beauty treatments. Our skilled technicians use only the highest quality products for a luxurious experience.",
    rating: 4.6,
    reviewCount: 98,
    image: "/placeholder.svg?height=300&width=600",
    logo: "/placeholder.svg?height=80&width=80",
    hours: [
      { day: "Monday", hours: "10:00 AM - 6:00 PM" },
      { day: "Tuesday", hours: "10:00 AM - 6:00 PM" },
      { day: "Wednesday", hours: "10:00 AM - 6:00 PM" },
      { day: "Thursday", hours: "10:00 AM - 7:00 PM" },
      { day: "Friday", hours: "10:00 AM - 7:00 PM" },
      { day: "Saturday", hours: "9:00 AM - 5:00 PM" },
      { day: "Sunday", hours: "Closed" },
    ],
    services: [
      {
        id: 4,
        name: "Basic Manicure",
        description: "Clean, shape, and polish your nails with our basic manicure.",
        price: 25,
        duration: 30,
      },
      {
        id: 5,
        name: "Gel Manicure",
        description: "Long-lasting gel polish application with nail preparation.",
        price: 40,
        duration: 45,
      },
      {
        id: 6,
        name: "Pedicure",
        description: "Relaxing foot treatment with nail care and polish.",
        price: 45,
        duration: 60,
      },
      {
        id: 7,
        name: "Full Facial",
        description: "Deep cleansing facial with massage and mask.",
        price: 75,
        duration: 60,
      },
    ],
    reviews: [
      {
        id: 204,
        author: "Lisa T.",
        rating: 5,
        date: "2023-06-02",
        comment: "Amazing facial! My skin feels so refreshed.",
      },
      { id: 205, author: "Michelle P.", rating: 4, date: "2023-05-18", comment: "Great manicure, lasted for weeks." },
      {
        id: 206,
        author: "Jennifer R.",
        rating: 5,
        date: "2023-04-30",
        comment: "Wonderful experience from start to finish.",
      },
    ],
  },
]

// Mock data for customer favorites
const customerFavorites = [1, 5, 14] // Service IDs that are favorited

export default function PartnerDetailPage({ params }: { params: { id: string } }) {
  const partnerId = Number.parseInt(params.id)
  const partner = partnersData.find((p) => p.id === partnerId)
  const [favorites, setFavorites] = useState<number[]>(customerFavorites)
  const { showNotification } = useNotificationContext()
  const router = useRouter()

  if (!partner) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h1 className="text-2xl font-bold mb-4">Partner Not Found</h1>
        <p className="mb-6">The partner you're looking for doesn't exist or has been removed.</p>
        <Button asChild>
          <Link href="/customer/dashboard">Return to Dashboard</Link>
        </Button>
      </div>
    )
  }

  const toggleFavorite = (serviceId: number) => {
    if (favorites.includes(serviceId)) {
      setFavorites(favorites.filter((id) => id !== serviceId))
      showNotification({
        title: "Removed from favorites",
        description: "Service has been removed from your favorites.",
      })
    } else {
      setFavorites([...favorites, serviceId])
      showNotification({
        title: "Added to favorites",
        description: "Service has been added to your favorites.",
      })
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <Button variant="ghost" asChild className="mb-2">
            <Link href="/customer/dashboard">
              <ArrowLeft className="h-4 w-4 mr-2" /> Back to Dashboard
            </Link>
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        {/* Partner Header */}
        <div className="relative mb-8">
          <div className="w-full h-48 md:h-64 rounded-lg overflow-hidden relative">
            <Image src={partner.image || "/placeholder.svg"} alt={partner.businessName} fill className="object-cover" />
          </div>
          <div className="flex flex-col md:flex-row md:items-end -mt-16 md:-mt-20 relative z-10 px-4">
            <div className="w-24 h-24 md:w-32 md:h-32 bg-white rounded-lg shadow-md overflow-hidden border-4 border-white">
              <Image
                src={partner.logo || "/placeholder.svg"}
                alt={partner.businessName}
                width={128}
                height={128}
                className="object-cover"
              />
            </div>
            <div className="mt-4 md:mt-0 md:ml-6 bg-white md:bg-transparent p-4 md:p-0 rounded-lg md:rounded-none shadow-md md:shadow-none flex-1">
              <div className="flex flex-col md:flex-row md:items-center justify-between">
                <div>
                  <h1 className="text-2xl font-bold">{partner.businessName}</h1>
                  <div className="flex items-center mt-1">
                    <div className="flex items-center text-amber-500">
                      <Star className="h-4 w-4 fill-amber-500" />
                      <span className="ml-1 font-medium">{partner.rating}</span>
                    </div>
                    <span className="mx-2 text-gray-400">•</span>
                    <span className="text-sm text-gray-600">{partner.reviewCount} reviews</span>
                  </div>
                  <p className="flex items-center text-gray-600 mt-1">
                    <MapPin className="h-4 w-4 mr-1" />
                    {partner.address}
                  </p>
                </div>
                <div className="flex mt-4 md:mt-0 space-x-2">
                  <Button variant="outline" size="sm">
                    <Share2 className="h-4 w-4 mr-2" /> Share
                  </Button>
                  <Button variant="outline" size="sm">
                    <MessageSquare className="h-4 w-4 mr-2" /> Contact
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <Tabs defaultValue="services" className="mt-8">
          <TabsList>
            <TabsTrigger value="services">Services</TabsTrigger>
            <TabsTrigger value="about">About</TabsTrigger>
            <TabsTrigger value="reviews">Reviews</TabsTrigger>
          </TabsList>

          <TabsContent value="services" className="mt-6">
            <h2 className="text-xl font-semibold mb-4">Available Services</h2>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {partner.services.map((service) => (
                <Card key={service.id} className="overflow-hidden">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between">
                      <CardTitle className="text-lg">{service.name}</CardTitle>
                      <Button
                        variant="ghost"
                        size="icon"
                        className={favorites.includes(service.id) ? "text-red-500" : "text-gray-400"}
                        onClick={() => toggleFavorite(service.id)}
                      >
                        <Heart className={favorites.includes(service.id) ? "fill-red-500" : ""} />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-4">{service.description}</p>
                    <div className="flex flex-wrap gap-2 text-xs">
                      <Badge variant="outline" className="flex items-center gap-1">
                        <DollarSign className="h-3 w-3" /> ${service.price}
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Clock className="h-3 w-3" /> {service.duration} min
                      </Badge>
                    </div>
                  </CardContent>
                  <CardFooter className="border-t pt-4">
                    <Button
                      className="w-full"
                      onClick={() => {
                        showNotification({
                          title: "Booking initiated",
                          description: `You're booking ${service.name} at ${partner.businessName}.`,
                        })
                        router.push(`/customer/book/${service.id}`)
                      }}
                    >
                      Book Appointment
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="about" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>About {partner.businessName}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="font-medium mb-2">Description</h3>
                  <p className="text-muted-foreground">{partner.description}</p>
                </div>

                <div>
                  <h3 className="font-medium mb-2">Contact Information</h3>
                  <div className="space-y-2">
                    <p className="flex items-center text-muted-foreground">
                      <Phone className="h-4 w-4 mr-2" /> {partner.phone}
                    </p>
                    <p className="flex items-center text-muted-foreground">
                      <Mail className="h-4 w-4 mr-2" /> {partner.email}
                    </p>
                    <p className="flex items-center text-muted-foreground">
                      <Globe className="h-4 w-4 mr-2" /> {partner.website}
                    </p>
                    <p className="flex items-center text-muted-foreground">
                      <MapPin className="h-4 w-4 mr-2" /> {partner.address}
                    </p>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium mb-2">Business Hours</h3>
                  <div className="grid grid-cols-2 gap-2">
                    {partner.hours.map((item) => (
                      <div key={item.day} className="flex justify-between">
                        <span className="font-medium">{item.day}</span>
                        <span className="text-muted-foreground">{item.hours}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reviews" className="mt-6">
            <div className="mb-6">
              <div className="flex items-center mb-2">
                <h2 className="text-xl font-semibold">Customer Reviews</h2>
                <div className="ml-4 flex items-center">
                  <div className="flex items-center text-amber-500">
                    <Star className="h-5 w-5 fill-amber-500" />
                    <span className="ml-1 font-medium">{partner.rating}</span>
                  </div>
                  <span className="mx-2 text-gray-400">•</span>
                  <span className="text-sm text-gray-600">{partner.reviewCount} reviews</span>
                </div>
              </div>
              <Button>Write a Review</Button>
            </div>

            <div className="space-y-6">
              {partner.reviews.map((review) => (
                <Card key={review.id}>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center">
                        <Avatar className="h-10 w-10 mr-3">
                          <AvatarFallback>{review.author[0]}</AvatarFallback>
                        </Avatar>
                        <div>
                          <CardTitle className="text-base">{review.author}</CardTitle>
                          <CardDescription>{new Date(review.date).toLocaleDateString()}</CardDescription>
                        </div>
                      </div>
                      <div className="flex">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star
                            key={i}
                            className={`h-4 w-4 ${i < review.rating ? "text-amber-500 fill-amber-500" : "text-gray-300"}`}
                          />
                        ))}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{review.comment}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

