"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { format } from "date-fns"
import { CalendarIcon, ArrowLeft, Clock, DollarSign } from "lucide-react"
import { cn } from "@/lib/utils"
import { useNotificationContext } from "@/components/notification-provider"

// Mock data for partners and their services
const partnersData = [
  {
    id: 101,
    businessName: "Scissors & Combs",
    address: "101 Elm St, Anytown, USA",
    services: [
      {
        id: 1,
        name: "Men's Haircut",
        description: "Professional haircut for men including wash and style.",
        price: 35,
        duration: 30,
      },
      {
        id: 2,
        name: "Women's Haircut",
        description: "Professional haircut for women including wash and style.",
        price: 55,
        duration: 45,
      },
      {
        id: 3,
        name: "Hair Coloring",
        description: "Full hair coloring service with premium products.",
        price: 85,
        duration: 90,
      },
    ],
  },
  {
    id: 102,
    businessName: "Glamour Zone",
    address: "202 Maple Ave, Somewhere, USA",
    services: [
      {
        id: 4,
        name: "Basic Manicure",
        description: "Clean, shape, and polish your nails with our basic manicure.",
        price: 25,
        duration: 30,
      },
      {
        id: 5,
        name: "Gel Manicure",
        description: "Long-lasting gel polish application with nail preparation.",
        price: 40,
        duration: 45,
      },
      {
        id: 6,
        name: "Pedicure",
        description: "Relaxing foot treatment with nail care and polish.",
        price: 45,
        duration: 60,
      },
      {
        id: 7,
        name: "Full Facial",
        description: "Deep cleansing facial with massage and mask.",
        price: 75,
        duration: 60,
      },
    ],
  },
]

// Generate available time slots
const generateTimeSlots = () => {
  const slots = []
  const startHour = 9 // 9 AM
  const endHour = 18 // 6 PM

  for (let hour = startHour; hour < endHour; hour++) {
    for (let minute = 0; minute < 60; minute += 30) {
      const formattedHour = hour % 12 === 0 ? 12 : hour % 12
      const period = hour < 12 ? "AM" : "PM"
      const formattedMinute = minute === 0 ? "00" : minute

      slots.push({
        value: `${hour}:${formattedMinute}`,
        label: `${formattedHour}:${formattedMinute} ${period}`,
      })
    }
  }

  return slots
}

const timeSlots = generateTimeSlots()

export default function BookingPage({ params }: { params: { id: string } }) {
  const serviceId = Number.parseInt(params.id)

  // Find the service and its partner
  let selectedService = null
  let partner = null

  for (const p of partnersData) {
    const service = p.services.find((s) => s.id === serviceId)
    if (service) {
      selectedService = service
      partner = p
      break
    }
  }

  const [date, setDate] = useState<Date | undefined>(undefined)
  const [timeSlot, setTimeSlot] = useState<string | undefined>(undefined)
  const [notes, setNotes] = useState("")
  const { showNotification } = useNotificationContext()
  const router = useRouter()

  if (!selectedService || !partner) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h1 className="text-2xl font-bold mb-4">Service Not Found</h1>
        <p className="mb-6">The service you're looking for doesn't exist or has been removed.</p>
        <Button asChild>
          <Link href="/customer/dashboard">Return to Dashboard</Link>
        </Button>
      </div>
    )
  }

  const handleBooking = () => {
    if (!date || !timeSlot) {
      showNotification({
        title: "Booking Error",
        description: "Please select both a date and time for your appointment.",
        variant: "destructive",
      })
      return
    }

    // In a real app, this would make an API call to create the booking
    showNotification({
      title: "Booking Confirmed",
      description: `Your appointment for ${selectedService.name} has been booked successfully.`,
    })

    router.push("/customer/dashboard")
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <Button variant="ghost" asChild className="mb-2">
            <Link href="/customer/dashboard">
              <ArrowLeft className="h-4 w-4 mr-2" /> Back to Dashboard
            </Link>
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-6">Book Appointment</h1>

        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Select Date & Time</CardTitle>
                <CardDescription>Choose when you'd like to schedule your appointment</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label>Date</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {date ? format(date, "PPP") : "Select a date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={date}
                          onSelect={setDate}
                          initialFocus
                          disabled={
                            (date) => date < new Date(new Date().setHours(0, 0, 0, 0)) || date.getDay() === 0 // Disable Sundays
                          }
                        />
                      </PopoverContent>
                    </Popover>
                  </div>

                  <div className="space-y-2">
                    <Label>Time</Label>
                    <RadioGroup value={timeSlot} onValueChange={setTimeSlot} className="grid grid-cols-3 gap-2">
                      {timeSlots.map((slot) => (
                        <div key={slot.value}>
                          <RadioGroupItem value={slot.value} id={`time-${slot.value}`} className="peer sr-only" />
                          <Label
                            htmlFor={`time-${slot.value}`}
                            className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-2 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                          >
                            <Clock className="mb-1 h-4 w-4" />
                            {slot.label}
                          </Label>
                        </div>
                      ))}
                    </RadioGroup>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">Special Requests or Notes</Label>
                  <Textarea
                    id="notes"
                    placeholder="Any special requests or information for your stylist..."
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card>
              <CardHeader>
                <CardTitle>Booking Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="font-medium">Service</h3>
                  <p className="text-lg">{selectedService.name}</p>
                  <p className="text-sm text-muted-foreground">{selectedService.description}</p>
                </div>

                <div>
                  <h3 className="font-medium">Provider</h3>
                  <p>{partner.businessName}</p>
                  <p className="text-sm text-muted-foreground">{partner.address}</p>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
                    <span>{selectedService.duration} minutes</span>
                  </div>
                  <div className="flex items-center">
                    <DollarSign className="h-4 w-4 mr-1 text-muted-foreground" />
                    <span className="text-lg font-semibold">${selectedService.price}</span>
                  </div>
                </div>

                {date && timeSlot && (
                  <div className="border-t pt-4 mt-4">
                    <h3 className="font-medium">Appointment Time</h3>
                    <p>{format(date, "PPP")}</p>
                    <p>{timeSlots.find((slot) => slot.value === timeSlot)?.label}</p>
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button className="w-full" onClick={handleBooking}>
                  Confirm Booking
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

