"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Heart, Search, MapPin, Clock, DollarSign, Star, LogOut, User, Bookmark, Calendar } from "lucide-react"
import { useNotificationContext } from "@/components/notification-provider"

// Mock data for partners and their services
const partnersData = [
  {
    id: 101,
    businessName: "Scissors & Combs",
    ownerName: "Michael Brown",
    address: "101 Elm St, Anytown, USA",
    rating: 4.8,
    reviewCount: 124,
    image: "/placeholder.svg?height=80&width=80",
    services: [
      {
        id: 1,
        name: "Men's Haircut",
        description: "Professional haircut for men including wash and style.",
        price: 35,
        duration: 30,
      },
      {
        id: 2,
        name: "Women's Haircut",
        description: "Professional haircut for women including wash and style.",
        price: 55,
        duration: 45,
      },
      {
        id: 3,
        name: "Hair Coloring",
        description: "Full hair coloring service with premium products.",
        price: 85,
        duration: 90,
      },
    ],
  },
  {
    id: 102,
    businessName: "Glamour Zone",
    ownerName: "Emily Wilson",
    address: "202 Maple Ave, Somewhere, USA",
    rating: 4.6,
    reviewCount: 98,
    image: "/placeholder.svg?height=80&width=80",
    services: [
      {
        id: 4,
        name: "Basic Manicure",
        description: "Clean, shape, and polish your nails with our basic manicure.",
        price: 25,
        duration: 30,
      },
      {
        id: 5,
        name: "Gel Manicure",
        description: "Long-lasting gel polish application with nail preparation.",
        price: 40,
        duration: 45,
      },
      {
        id: 6,
        name: "Pedicure",
        description: "Relaxing foot treatment with nail care and polish.",
        price: 45,
        duration: 60,
      },
      {
        id: 7,
        name: "Full Facial",
        description: "Deep cleansing facial with massage and mask.",
        price: 75,
        duration: 60,
      },
    ],
  },
  {
    id: 103,
    businessName: "The Style Hub",
    ownerName: "David Lee",
    address: "303 Cedar Rd, Elsewhere, USA",
    rating: 4.9,
    reviewCount: 76,
    image: "/placeholder.svg?height=80&width=80",
    services: [
      { id: 8, name: "Beard Trim", description: "Professional beard trimming and shaping.", price: 15, duration: 15 },
      {
        id: 9,
        name: "Hair & Beard Combo",
        description: "Complete haircut and beard trim package.",
        price: 45,
        duration: 45,
      },
      { id: 10, name: "Kid's Haircut", description: "Gentle haircuts for children under 12.", price: 25, duration: 20 },
    ],
  },
  {
    id: 104,
    businessName: "Nail Paradise",
    ownerName: "Jessica Wong",
    address: "404 Pine St, Anytown, USA",
    rating: 4.7,
    reviewCount: 112,
    image: "/placeholder.svg?height=80&width=80",
    services: [
      {
        id: 11,
        name: "Nail Art",
        description: "Custom nail art and designs for any occasion.",
        price: 35,
        duration: 45,
      },
      {
        id: 12,
        name: "Acrylic Nails",
        description: "Full set of acrylic nails with your choice of color.",
        price: 60,
        duration: 75,
      },
      {
        id: 13,
        name: "Nail Repair",
        description: "Fix broken or damaged nails with our repair service.",
        price: 15,
        duration: 20,
      },
    ],
  },
  {
    id: 105,
    businessName: "Relaxation Spa",
    ownerName: "Amanda Chen",
    address: "505 Oak Dr, Somewhere, USA",
    rating: 4.9,
    reviewCount: 203,
    image: "/placeholder.svg?height=80&width=80",
    services: [
      {
        id: 14,
        name: "Swedish Massage",
        description: "Full-body relaxation massage to relieve tension.",
        price: 80,
        duration: 60,
      },
      {
        id: 15,
        name: "Deep Tissue Massage",
        description: "Targeted massage for chronic muscle tension.",
        price: 95,
        duration: 60,
      },
      {
        id: 16,
        name: "Hot Stone Therapy",
        description: "Massage with heated stones for deep relaxation.",
        price: 110,
        duration: 90,
      },
    ],
  },
]

// Mock data for customer
const customerData = {
  id: 201,
  name: "Alex Johnson",
  email: "alex@example.com",
  phone: "555-123-4567",
  favorites: [1, 5, 14], // Service IDs that are favorited
  appointments: [
    { id: 301, serviceId: 2, partnerId: 101, date: "2023-07-15T14:30:00Z", status: "completed" },
    { id: 302, serviceId: 6, partnerId: 102, date: "2023-08-20T10:00:00Z", status: "completed" },
    { id: 303, serviceId: 14, partnerId: 105, date: "2023-09-05T15:00:00Z", status: "upcoming" },
  ],
}

// Flatten all services for easy searching
const allServices = partnersData.flatMap((partner) =>
  partner.services.map((service) => ({
    ...service,
    partnerId: partner.id,
    partnerName: partner.businessName,
    partnerAddress: partner.address,
    partnerImage: partner.image,
    partnerRating: partner.rating,
  })),
)

export default function CustomerDashboard() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filteredServices, setFilteredServices] = useState(allServices)
  const [favorites, setFavorites] = useState<number[]>(customerData.favorites)
  const { showNotification } = useNotificationContext()
  const router = useRouter()

  // Filter services based on search term
  useEffect(() => {
    if (searchTerm.trim() === "") {
      setFilteredServices(allServices)
    } else {
      const term = searchTerm.toLowerCase()
      const filtered = allServices.filter(
        (service) =>
          service.name.toLowerCase().includes(term) ||
          service.description.toLowerCase().includes(term) ||
          service.partnerName.toLowerCase().includes(term),
      )
      setFilteredServices(filtered)
    }
  }, [searchTerm])

  const toggleFavorite = (serviceId: number) => {
    if (favorites.includes(serviceId)) {
      setFavorites(favorites.filter((id) => id !== serviceId))
      showNotification({
        title: "Removed from favorites",
        description: "Service has been removed from your favorites.",
      })
    } else {
      setFavorites([...favorites, serviceId])
      showNotification({
        title: "Added to favorites",
        description: "Service has been added to your favorites.",
      })
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "2-digit",
    })
  }

  const getFavoriteServices = () => {
    return allServices.filter((service) => favorites.includes(service.id))
  }

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <div className="w-64 bg-gray-900 text-white p-4 hidden md:block">
        <div className="mb-8">
          <h2 className="text-xl font-bold">SalonConnect</h2>
          <p className="text-sm text-gray-400">Customer Dashboard</p>
        </div>

        <div className="mb-6">
          <div className="flex items-center space-x-3 mb-4">
            <Avatar>
              <AvatarFallback>{customerData.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium">{customerData.name}</p>
              <p className="text-xs text-gray-400">{customerData.email}</p>
            </div>
          </div>
        </div>

        <nav className="space-y-1">
          <Link href="/customer/dashboard" className="flex items-center space-x-2 bg-gray-800 text-white rounded p-2">
            <User className="h-5 w-5" />
            <span>Dashboard</span>
          </Link>
          <Link
            href="/customer/favorites"
            className="flex items-center space-x-2 text-gray-300 hover:bg-gray-800 rounded p-2"
          >
            <Bookmark className="h-5 w-5" />
            <span>Favorites</span>
          </Link>
          <Link
            href="/customer/appointments"
            className="flex items-center space-x-2 text-gray-300 hover:bg-gray-800 rounded p-2"
          >
            <Calendar className="h-5 w-5" />
            <span>Appointments</span>
          </Link>
          <Link href="/login" className="flex items-center space-x-2 text-gray-300 hover:bg-gray-800 rounded p-2">
            <LogOut className="h-5 w-5" />
            <span>Logout</span>
          </Link>
        </nav>
      </div>

      {/* Main content */}
      <div className="flex-1 bg-gray-50">
        <header className="bg-white border-b p-4 flex justify-between items-center">
          <h1 className="text-xl font-bold">Customer Dashboard</h1>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-muted-foreground">{customerData.email}</span>
            <Avatar>
              <AvatarFallback>{customerData.name.charAt(0)}</AvatarFallback>
            </Avatar>
          </div>
        </header>

        <main className="p-6">
          <div className="mb-8">
            <div className="relative max-w-xl mx-auto mb-6">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search for services, salons, or treatments..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>

          <Tabs defaultValue="all">
            <TabsList className="mb-6">
              <TabsTrigger value="all">All Services</TabsTrigger>
              <TabsTrigger value="favorites">
                Favorites
                {favorites.length > 0 && (
                  <Badge variant="secondary" className="ml-2">
                    {favorites.length}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="appointments">Appointments</TabsTrigger>
            </TabsList>

            <TabsContent value="all">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {filteredServices.length === 0 ? (
                  <div className="md:col-span-2 lg:col-span-3 text-center py-10">
                    <p className="text-muted-foreground">No services found matching your search.</p>
                  </div>
                ) : (
                  filteredServices.map((service) => (
                    <Card key={service.id} className="overflow-hidden">
                      <CardHeader className="pb-2">
                        <div className="flex justify-between">
                          <div>
                            <CardTitle className="text-lg">{service.name}</CardTitle>
                            <CardDescription className="flex items-center mt-1">
                              <Link href={`/customer/partners/${service.partnerId}`} className="hover:underline">
                                {service.partnerName}
                              </Link>
                              <span className="flex items-center ml-2 text-amber-500">
                                <Star className="h-3 w-3 fill-amber-500 mr-1" />
                                {service.partnerRating}
                              </span>
                            </CardDescription>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className={favorites.includes(service.id) ? "text-red-500" : "text-gray-400"}
                            onClick={() => toggleFavorite(service.id)}
                          >
                            <Heart className={favorites.includes(service.id) ? "fill-red-500" : ""} />
                          </Button>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground mb-4">{service.description}</p>
                        <div className="flex flex-wrap gap-2 text-xs">
                          <Badge variant="outline" className="flex items-center gap-1">
                            <DollarSign className="h-3 w-3" /> ${service.price}
                          </Badge>
                          <Badge variant="outline" className="flex items-center gap-1">
                            <Clock className="h-3 w-3" /> {service.duration} min
                          </Badge>
                          <Badge variant="outline" className="flex items-center gap-1 max-w-full truncate">
                            <MapPin className="h-3 w-3 shrink-0" />
                            <span className="truncate">{service.partnerAddress}</span>
                          </Badge>
                        </div>
                      </CardContent>
                      <CardFooter className="border-t pt-4">
                        <Button
                          className="w-full"
                          onClick={() => {
                            showNotification({
                              title: "Booking initiated",
                              description: `You're booking ${service.name} at ${service.partnerName}.`,
                            })
                            router.push(`/customer/book/${service.id}`)
                          }}
                        >
                          Book Appointment
                        </Button>
                      </CardFooter>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="favorites">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {getFavoriteServices().length === 0 ? (
                  <div className="md:col-span-2 lg:col-span-3 text-center py-10">
                    <p className="text-muted-foreground">You haven't added any services to your favorites yet.</p>
                    <Button
                      variant="outline"
                      className="mt-4"
                      onClick={() => document.querySelector('[data-value="all"]')?.click()}
                    >
                      Browse Services
                    </Button>
                  </div>
                ) : (
                  getFavoriteServices().map((service) => (
                    <Card key={service.id} className="overflow-hidden">
                      <CardHeader className="pb-2">
                        <div className="flex justify-between">
                          <div>
                            <CardTitle className="text-lg">{service.name}</CardTitle>
                            <CardDescription className="flex items-center mt-1">
                              <Link href={`/customer/partners/${service.partnerId}`} className="hover:underline">
                                {service.partnerName}
                              </Link>
                              <span className="flex items-center ml-2 text-amber-500">
                                <Star className="h-3 w-3 fill-amber-500 mr-1" />
                                {service.partnerRating}
                              </span>
                            </CardDescription>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-red-500"
                            onClick={() => toggleFavorite(service.id)}
                          >
                            <Heart className="fill-red-500" />
                          </Button>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground mb-4">{service.description}</p>
                        <div className="flex flex-wrap gap-2 text-xs">
                          <Badge variant="outline" className="flex items-center gap-1">
                            <DollarSign className="h-3 w-3" /> ${service.price}
                          </Badge>
                          <Badge variant="outline" className="flex items-center gap-1">
                            <Clock className="h-3 w-3" /> {service.duration} min
                          </Badge>
                          <Badge variant="outline" className="flex items-center gap-1 max-w-full truncate">
                            <MapPin className="h-3 w-3 shrink-0" />
                            <span className="truncate">{service.partnerAddress}</span>
                          </Badge>
                        </div>
                      </CardContent>
                      <CardFooter className="border-t pt-4">
                        <Button
                          className="w-full"
                          onClick={() => {
                            showNotification({
                              title: "Booking initiated",
                              description: `You're booking ${service.name} at ${service.partnerName}.`,
                            })
                            router.push(`/customer/book/${service.id}`)
                          }}
                        >
                          Book Appointment
                        </Button>
                      </CardFooter>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="appointments">
              <div className="space-y-6">
                <h2 className="text-xl font-semibold mb-4">Your Appointments</h2>

                {customerData.appointments.length === 0 ? (
                  <Card>
                    <CardContent className="pt-6 text-center text-muted-foreground">
                      You don't have any appointments yet.
                    </CardContent>
                  </Card>
                ) : (
                  <>
                    <h3 className="text-lg font-medium">Upcoming</h3>
                    {customerData.appointments
                      .filter((appointment) => appointment.status === "upcoming")
                      .map((appointment) => {
                        const service = allServices.find((s) => s.id === appointment.serviceId)
                        const partner = partnersData.find((p) => p.id === appointment.partnerId)

                        if (!service || !partner) return null

                        return (
                          <Card key={appointment.id}>
                            <CardHeader className="pb-2">
                              <div className="flex justify-between items-start">
                                <div>
                                  <CardTitle>{service.name}</CardTitle>
                                  <CardDescription>{partner.businessName}</CardDescription>
                                </div>
                                <Badge className="bg-blue-100 text-blue-800 border-blue-200">Upcoming</Badge>
                              </div>
                            </CardHeader>
                            <CardContent>
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                                <div>
                                  <p className="font-medium">Date & Time</p>
                                  <p className="text-muted-foreground">{formatDate(appointment.date)}</p>
                                </div>
                                <div>
                                  <p className="font-medium">Duration</p>
                                  <p className="text-muted-foreground">{service.duration} minutes</p>
                                </div>
                                <div>
                                  <p className="font-medium">Price</p>
                                  <p className="text-muted-foreground">${service.price}</p>
                                </div>
                                <div className="md:col-span-3">
                                  <p className="font-medium">Location</p>
                                  <p className="text-muted-foreground">{partner.address}</p>
                                </div>
                              </div>
                            </CardContent>
                            <CardFooter className="border-t pt-4 flex justify-end space-x-2">
                              <Button variant="outline">Reschedule</Button>
                              <Button variant="destructive">Cancel</Button>
                            </CardFooter>
                          </Card>
                        )
                      })}

                    <h3 className="text-lg font-medium mt-8">Past Appointments</h3>
                    {customerData.appointments
                      .filter((appointment) => appointment.status === "completed")
                      .map((appointment) => {
                        const service = allServices.find((s) => s.id === appointment.serviceId)
                        const partner = partnersData.find((p) => p.id === appointment.partnerId)

                        if (!service || !partner) return null

                        return (
                          <Card key={appointment.id}>
                            <CardHeader className="pb-2">
                              <div className="flex justify-between items-start">
                                <div>
                                  <CardTitle>{service.name}</CardTitle>
                                  <CardDescription>{partner.businessName}</CardDescription>
                                </div>
                                <Badge variant="outline" className="bg-gray-100 text-gray-800 border-gray-200">
                                  Completed
                                </Badge>
                              </div>
                            </CardHeader>
                            <CardContent>
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                                <div>
                                  <p className="font-medium">Date & Time</p>
                                  <p className="text-muted-foreground">{formatDate(appointment.date)}</p>
                                </div>
                                <div>
                                  <p className="font-medium">Duration</p>
                                  <p className="text-muted-foreground">{service.duration} minutes</p>
                                </div>
                                <div>
                                  <p className="font-medium">Price</p>
                                  <p className="text-muted-foreground">${service.price}</p>
                                </div>
                              </div>
                            </CardContent>
                            <CardFooter className="border-t pt-4 flex justify-end">
                              <Button variant="outline">Book Again</Button>
                            </CardFooter>
                          </Card>
                        )
                      })}
                  </>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  )
}

