import { NextResponse } from "next/server"
import { db } from "@/lib/db"

export async function POST(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = Number.parseInt(params.id)

    const partner = await db.partners.update(id, {
      status: "rejected",
    })

    return NextResponse.json(partner)
  } catch (error) {
    return NextResponse.json({ error: "Failed to reject partner" }, { status: 500 })
  }
}

