import { NextResponse } from "next/server"
import { db } from "@/lib/db"

export async function GET() {
  try {
    const partners = await db.partners.findMany()
    return NextResponse.json(partners)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch partners" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    // In a real app, you would validate the input data
    const partner = await db.partners.create(body)

    return NextResponse.json(partner, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: "Failed to create partner" }, { status: 500 })
  }
}

