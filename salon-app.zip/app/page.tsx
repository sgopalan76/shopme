import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Scissors, Users, Settings, List } from "lucide-react"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Link href="/" className="text-2xl font-bold text-primary">
            SalonConnect
          </Link>
          <nav className="space-x-4">
            <Link href="/login" className="text-sm font-medium hover:underline">
              Login
            </Link>
            <div className="inline-flex space-x-2">
              <Link href="/register">
                <Button variant="outline">Partner Register</Button>
              </Link>
              <Link href="/customer/register">
                <Button>Customer Register</Button>
              </Link>
            </div>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <section className="py-20 bg-gradient-to-b from-white to-gray-50">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">Find and Book Salon Services</h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10">
              Discover and book appointments with top salon professionals in your area.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link href="/customer/register">
                <Button size="lg" className="w-full sm:w-auto">
                  Sign Up as Customer
                </Button>
              </Link>
              <Link href="/customer/dashboard">
                <Button size="lg" variant="outline" className="w-full sm:w-auto">
                  Browse Services
                </Button>
              </Link>
            </div>
          </div>
        </section>

        <section className="py-16 container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">How It Works</h2>
          <div className="grid md:grid-cols-4 gap-8">
            <Card>
              <CardHeader>
                <Scissors className="h-12 w-12 text-primary mb-2" />
                <CardTitle>Find Services</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">Browse through a wide range of salon services in your area.</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Users className="h-12 w-12 text-primary mb-2" />
                <CardTitle>Choose a Provider</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Select from our verified salon partners based on reviews and ratings.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Settings className="h-12 w-12 text-primary mb-2" />
                <CardTitle>Book Appointment</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">Schedule your appointment at a time that works for you.</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <List className="h-12 w-12 text-primary mb-2" />
                <CardTitle>Get Service</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Enjoy your salon service and leave a review about your experience.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        <section className="py-16 bg-primary text-primary-foreground">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-6">Ready to Get Started?</h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto opacity-90">
              Join hundreds of customers already booking salon services with SalonConnect.
            </p>
            <Link href="/customer/register">
              <Button size="lg" variant="secondary">
                Sign Up Now
              </Button>
            </Link>
          </div>
        </section>
      </main>

      <footer className="bg-gray-900 text-gray-300 py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4 text-white">SalonConnect</h3>
              <p className="mb-4">Connecting salon businesses with new clients.</p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4 text-white">Quick Links</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/" className="hover:text-white">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="/about" className="hover:text-white">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="/services" className="hover:text-white">
                    Services
                  </Link>
                </li>
                <li>
                  <Link href="/register" className="hover:text-white">
                    Partner Register
                  </Link>
                </li>
                <li>
                  <Link href="/customer/register" className="hover:text-white">
                    Customer Register
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4 text-white">Contact</h4>
              <p>support@salonconnect.com</p>
              <p className="mt-4">© {new Date().getFullYear()} SalonConnect. All rights reserved.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

