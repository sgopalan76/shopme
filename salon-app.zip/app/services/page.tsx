import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Scissors, Search } from "lucide-react"

// Mock data for partners and services
const partners = [
  {
    id: 101,
    businessName: "Scissors & Combs",
    address: "101 Elm St, Anytown, USA",
    services: [
      { id: 1, name: "Men's Haircut", price: 35, duration: 30 },
      { id: 2, name: "Women's Haircut", price: 55, duration: 45 },
      { id: 3, name: "Hair Coloring", price: 85, duration: 90 },
    ],
  },
  {
    id: 102,
    businessName: "Glamour Zone",
    address: "202 Maple Ave, Somewhere, USA",
    services: [
      { id: 4, name: "Basic Manicure", price: 25, duration: 30 },
      { id: 5, name: "Gel Manicure", price: 40, duration: 45 },
      { id: 6, name: "Pedicure", price: 45, duration: 60 },
      { id: 7, name: "Full Facial", price: 75, duration: 60 },
    ],
  },
  {
    id: 103,
    businessName: "The Style Hub",
    address: "303 Cedar Rd, Elsewhere, USA",
    services: [
      { id: 8, name: "Beard Trim", price: 15, duration: 15 },
      { id: 9, name: "Hair & Beard Combo", price: 45, duration: 45 },
      { id: 10, name: "Kid's Haircut", price: 25, duration: 20 },
    ],
  },
]

export default function ServicesPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Link href="/" className="text-2xl font-bold text-primary">
            SalonConnect
          </Link>
          <nav className="space-x-4">
            <Link href="/login" className="text-sm font-medium hover:underline">
              Login
            </Link>
            <Link href="/register">
              <Button>Register</Button>
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1 bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-2xl mx-auto mb-8 text-center">
            <h1 className="text-3xl font-bold mb-4">Browse Salon Services</h1>
            <p className="text-muted-foreground mb-6">Discover services offered by our partner salons.</p>
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search for services or salons..." className="pl-10" />
            </div>
          </div>

          <div className="space-y-10">
            {partners.map((partner) => (
              <div key={partner.id} className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Scissors className="h-5 w-5 text-primary" />
                  <h2 className="text-xl font-bold">{partner.businessName}</h2>
                </div>
                <p className="text-muted-foreground">{partner.address}</p>

                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {partner.services.map((service) => (
                    <Card key={service.id}>
                      <CardHeader>
                        <CardTitle>{service.name}</CardTitle>
                        <CardDescription>{service.duration} minutes</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <p className="text-2xl font-bold">${service.price}</p>
                      </CardContent>
                      <CardFooter>
                        <Button variant="outline" className="w-full">
                          View Details
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>

                <div className="pt-2">
                  <Link href={`/partners/${partner.id}`}>
                    <Button variant="link" className="p-0">
                      View all services from {partner.businessName}
                    </Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      <footer className="bg-gray-900 text-gray-300 py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4 text-white">SalonConnect</h3>
              <p className="mb-4">Connecting salon businesses with new clients.</p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4 text-white">Quick Links</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/" className="hover:text-white">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="/about" className="hover:text-white">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="/services" className="hover:text-white">
                    Services
                  </Link>
                </li>
                <li>
                  <Link href="/register" className="hover:text-white">
                    Register
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4 text-white">Contact</h4>
              <p>support@salonconnect.com</p>
              <p className="mt-4">© {new Date().getFullYear()} SalonConnect. All rights reserved.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

