"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Check, X, Users, Settings, LogOut } from "lucide-react"
import { useNotificationContext } from "@/components/notification-provider"

// Mock data for pending registrations
const pendingRegistrations = [
  {
    id: 1,
    businessName: "Elegant Cuts Salon",
    ownerName: "Jane Smith",
    email: "jane@elegantcuts.com",
    phone: "555-123-4567",
    address: "123 Main St, Anytown, USA",
    submittedAt: "2023-06-15T10:30:00Z",
  },
  {
    id: 2,
    businessName: "Modern Style Studio",
    ownerName: "John Davis",
    email: "john@modernstyle.com",
    phone: "555-987-6543",
    address: "456 Oak Ave, Somewhere, USA",
    submittedAt: "2023-06-14T14:45:00Z",
  },
  {
    id: 3,
    businessName: "Hair & Beauty Lounge",
    ownerName: "Sarah Johnson",
    email: "sarah@hairbeauty.com",
    phone: "555-456-7890",
    address: "789 Pine Rd, Elsewhere, USA",
    submittedAt: "2023-06-13T09:15:00Z",
  },
]

// Mock data for approved partners
const approvedPartners = [
  {
    id: 101,
    businessName: "Scissors & Combs",
    ownerName: "Michael Brown",
    email: "michael@scissorscombs.com",
    phone: "555-222-3333",
    address: "101 Elm St, Anytown, USA",
    approvedAt: "2023-06-10T11:20:00Z",
    servicesCount: 8,
  },
  {
    id: 102,
    businessName: "Glamour Zone",
    ownerName: "Emily Wilson",
    email: "emily@glamourzone.com",
    phone: "555-444-5555",
    address: "202 Maple Ave, Somewhere, USA",
    approvedAt: "2023-06-08T13:10:00Z",
    servicesCount: 12,
  },
  {
    id: 103,
    businessName: "The Style Hub",
    ownerName: "David Lee",
    email: "david@stylehub.com",
    phone: "555-666-7777",
    address: "303 Cedar Rd, Elsewhere, USA",
    approvedAt: "2023-06-05T15:30:00Z",
    servicesCount: 6,
  },
]

export default function AdminDashboard() {
  const [pendingList, setPendingList] = useState(pendingRegistrations)
  const [approvedList, setApprovedList] = useState(approvedPartners)
  const { showNotification } = useNotificationContext()

  const handleApprove = (id: number) => {
    const partnerToApprove = pendingList.find((partner) => partner.id === id)
    if (partnerToApprove) {
      // Remove from pending list
      setPendingList(pendingList.filter((partner) => partner.id !== id))

      // Add to approved list with additional properties
      setApprovedList([
        ...approvedList,
        {
          ...partnerToApprove,
          approvedAt: new Date().toISOString(),
          servicesCount: 0,
        },
      ])

      showNotification({
        title: "Partner Approved",
        description: `${partnerToApprove.businessName} has been approved successfully.`,
      })
    }
  }

  const handleReject = (id: number) => {
    const partnerToReject = pendingList.find((partner) => partner.id === id)
    if (partnerToReject) {
      // Remove from pending list
      setPendingList(pendingList.filter((partner) => partner.id !== id))

      showNotification({
        title: "Partner Rejected",
        description: `${partnerToReject.businessName} has been rejected.`,
      })
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <div className="w-64 bg-gray-900 text-white p-4 hidden md:block">
        <div className="mb-8">
          <h2 className="text-xl font-bold">SalonConnect</h2>
          <p className="text-sm text-gray-400">Admin Dashboard</p>
        </div>

        <nav className="space-y-1">
          <Link href="/admin/dashboard" className="flex items-center space-x-2 bg-gray-800 text-white rounded p-2">
            <Users className="h-5 w-5" />
            <span>Partners</span>
          </Link>
          <Link
            href="/admin/settings"
            className="flex items-center space-x-2 text-gray-300 hover:bg-gray-800 rounded p-2"
          >
            <Settings className="h-5 w-5" />
            <span>Settings</span>
          </Link>
          <Link href="/login" className="flex items-center space-x-2 text-gray-300 hover:bg-gray-800 rounded p-2">
            <LogOut className="h-5 w-5" />
            <span>Logout</span>
          </Link>
        </nav>
      </div>

      {/* Main content */}
      <div className="flex-1 bg-gray-50">
        <header className="bg-white border-b p-4 flex justify-between items-center">
          <h1 className="text-xl font-bold">Admin Dashboard</h1>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-muted-foreground">admin@salonconnect.com</span>
            <Avatar>
              <AvatarFallback>AD</AvatarFallback>
            </Avatar>
          </div>
        </header>

        <main className="p-6">
          <Tabs defaultValue="pending">
            <div className="flex justify-between items-center mb-6">
              <TabsList>
                <TabsTrigger value="pending">
                  Pending Registrations
                  {pendingList.length > 0 && (
                    <Badge variant="destructive" className="ml-2">
                      {pendingList.length}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="approved">Approved Partners</TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="pending">
              <div className="grid gap-4">
                {pendingList.length === 0 ? (
                  <Card>
                    <CardContent className="pt-6 text-center text-muted-foreground">
                      No pending registrations to review.
                    </CardContent>
                  </Card>
                ) : (
                  pendingList.map((partner) => (
                    <Card key={partner.id}>
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle>{partner.businessName}</CardTitle>
                            <CardDescription>Submitted on {formatDate(partner.submittedAt)}</CardDescription>
                          </div>
                          <div className="flex space-x-2">
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-red-500 border-red-200 hover:bg-red-50 hover:text-red-600"
                              onClick={() => handleReject(partner.id)}
                            >
                              <X className="h-4 w-4 mr-1" /> Reject
                            </Button>
                            <Button
                              size="sm"
                              className="bg-green-600 hover:bg-green-700"
                              onClick={() => handleApprove(partner.id)}
                            >
                              <Check className="h-4 w-4 mr-1" /> Approve
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                          <div>
                            <p className="font-medium">Owner</p>
                            <p className="text-muted-foreground">{partner.ownerName}</p>
                          </div>
                          <div>
                            <p className="font-medium">Contact</p>
                            <p className="text-muted-foreground">{partner.email}</p>
                            <p className="text-muted-foreground">{partner.phone}</p>
                          </div>
                          <div className="md:col-span-2">
                            <p className="font-medium">Address</p>
                            <p className="text-muted-foreground">{partner.address}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="approved">
              <div className="grid gap-4">
                {approvedList.length === 0 ? (
                  <Card>
                    <CardContent className="pt-6 text-center text-muted-foreground">
                      No approved partners yet.
                    </CardContent>
                  </Card>
                ) : (
                  approvedList.map((partner) => (
                    <Card key={partner.id}>
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle>{partner.businessName}</CardTitle>
                            <CardDescription>Approved on {formatDate(partner.approvedAt)}</CardDescription>
                          </div>
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            Approved
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                          <div>
                            <p className="font-medium">Owner</p>
                            <p className="text-muted-foreground">{partner.ownerName}</p>
                          </div>
                          <div>
                            <p className="font-medium">Contact</p>
                            <p className="text-muted-foreground">{partner.email}</p>
                            <p className="text-muted-foreground">{partner.phone}</p>
                          </div>
                          <div>
                            <p className="font-medium">Services</p>
                            <p className="text-muted-foreground">{partner.servicesCount} services listed</p>
                          </div>
                          <div className="md:col-span-3">
                            <p className="font-medium">Address</p>
                            <p className="text-muted-foreground">{partner.address}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  )
}

