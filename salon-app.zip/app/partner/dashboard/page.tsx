"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { User, Package, Settings, LogOut, Plus, Edit, Trash2 } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { useNotificationContext } from "@/components/notification-provider"

// Mock partner data
const partnerData = {
  id: 101,
  businessName: "Scissors & Combs",
  ownerName: "Michael Brown",
  email: "michael@scissorscombs.com",
  phone: "555-222-3333",
  address: "101 Elm St, Anytown, USA",
  description:
    "We specialize in modern haircuts and styling for all hair types. Our experienced stylists provide personalized service in a relaxing environment.",
  approvedAt: "2023-06-10T11:20:00Z",
}

// Mock services data
const initialServices = [
  {
    id: 1,
    name: "Men's Haircut",
    description: "Professional haircut for men including wash and style.",
    price: 35,
    duration: 30,
  },
  {
    id: 2,
    name: "Women's Haircut",
    description: "Professional haircut for women including wash and style.",
    price: 55,
    duration: 45,
  },
  {
    id: 3,
    name: "Hair Coloring",
    description: "Full hair coloring service with premium products.",
    price: 85,
    duration: 90,
  },
]

// Form schema for profile editing
const profileFormSchema = z.object({
  businessName: z.string().min(2, {
    message: "Business name must be at least 2 characters.",
  }),
  ownerName: z.string().min(2, {
    message: "Owner name must be at least 2 characters.",
  }),
  email: z.string().email({
    message: "Please enter a valid email address.",
  }),
  phone: z.string().min(10, {
    message: "Please enter a valid phone number.",
  }),
  address: z.string().min(5, {
    message: "Address must be at least 5 characters.",
  }),
  description: z.string().optional(),
})

// Form schema for service
const serviceFormSchema = z.object({
  name: z.string().min(2, {
    message: "Service name must be at least 2 characters.",
  }),
  description: z.string().min(5, {
    message: "Description must be at least 5 characters.",
  }),
  price: z.coerce.number().min(1, {
    message: "Price must be at least 1.",
  }),
  duration: z.coerce.number().min(5, {
    message: "Duration must be at least 5 minutes.",
  }),
})

export default function PartnerDashboard() {
  const [services, setServices] = useState(initialServices)
  const [isEditingProfile, setIsEditingProfile] = useState(false)
  const [isAddingService, setIsAddingService] = useState(false)
  const [editingServiceId, setEditingServiceId] = useState<number | null>(null)
  const { showNotification } = useNotificationContext()

  // Profile form
  const profileForm = useForm<z.infer<typeof profileFormSchema>>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      businessName: partnerData.businessName,
      ownerName: partnerData.ownerName,
      email: partnerData.email,
      phone: partnerData.phone,
      address: partnerData.address,
      description: partnerData.description,
    },
  })

  // Service form
  const serviceForm = useForm<z.infer<typeof serviceFormSchema>>({
    resolver: zodResolver(serviceFormSchema),
    defaultValues: {
      name: "",
      description: "",
      price: 0,
      duration: 0,
    },
  })

  const onProfileSubmit = (values: z.infer<typeof profileFormSchema>) => {
    // In a real app, this would update the profile via an API call
    showNotification({
      title: "Profile updated",
      description: "Your profile has been updated successfully.",
    })
    setIsEditingProfile(false)
  }

  const onServiceSubmit = (values: z.infer<typeof serviceFormSchema>) => {
    if (editingServiceId !== null) {
      // Update existing service
      setServices(
        services.map((service) => (service.id === editingServiceId ? { ...values, id: service.id } : service)),
      )
      showNotification({
        title: "Service updated",
        description: `${values.name} has been updated successfully.`,
      })
    } else {
      // Add new service
      const newService = {
        id: services.length > 0 ? Math.max(...services.map((s) => s.id)) + 1 : 1,
        ...values,
      }
      setServices([...services, newService])
      showNotification({
        title: "Service added",
        description: `${values.name} has been added successfully.`,
      })
    }

    setIsAddingService(false)
    setEditingServiceId(null)
    serviceForm.reset({
      name: "",
      description: "",
      price: 0,
      duration: 0,
    })
  }

  const handleEditService = (service: (typeof services)[0]) => {
    serviceForm.reset({
      name: service.name,
      description: service.description,
      price: service.price,
      duration: service.duration,
    })
    setEditingServiceId(service.id)
    setIsAddingService(true)
  }

  const handleDeleteService = (id: number) => {
    setServices(services.filter((service) => service.id !== id))
    showNotification({
      title: "Service deleted",
      description: "The service has been deleted successfully.",
    })
  }

  const handleAddNewService = () => {
    serviceForm.reset({
      name: "",
      description: "",
      price: 0,
      duration: 0,
    })
    setEditingServiceId(null)
    setIsAddingService(true)
  }

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <div className="w-64 bg-gray-900 text-white p-4 hidden md:block">
        <div className="mb-8">
          <h2 className="text-xl font-bold">SalonConnect</h2>
          <p className="text-sm text-gray-400">Partner Dashboard</p>
        </div>

        <nav className="space-y-1">
          <Link href="/partner/dashboard" className="flex items-center space-x-2 bg-gray-800 text-white rounded p-2">
            <User className="h-5 w-5" />
            <span>Profile</span>
          </Link>
          <Link
            href="/partner/services"
            className="flex items-center space-x-2 text-gray-300 hover:bg-gray-800 rounded p-2"
          >
            <Package className="h-5 w-5" />
            <span>Services</span>
          </Link>
          <Link
            href="/partner/settings"
            className="flex items-center space-x-2 text-gray-300 hover:bg-gray-800 rounded p-2"
          >
            <Settings className="h-5 w-5" />
            <span>Settings</span>
          </Link>
          <Link href="/login" className="flex items-center space-x-2 text-gray-300 hover:bg-gray-800 rounded p-2">
            <LogOut className="h-5 w-5" />
            <span>Logout</span>
          </Link>
        </nav>
      </div>

      {/* Main content */}
      <div className="flex-1 bg-gray-50">
        <header className="bg-white border-b p-4 flex justify-between items-center">
          <h1 className="text-xl font-bold">Partner Dashboard</h1>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-muted-foreground">{partnerData.email}</span>
            <Avatar>
              <AvatarFallback>{partnerData.ownerName.charAt(0)}</AvatarFallback>
            </Avatar>
          </div>
        </header>

        <main className="p-6">
          <Tabs defaultValue="profile">
            <div className="flex justify-between items-center mb-6">
              <TabsList>
                <TabsTrigger value="profile">Profile</TabsTrigger>
                <TabsTrigger value="services">Services</TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="profile">
              <Card>
                <CardHeader className="flex flex-row items-start justify-between">
                  <div>
                    <CardTitle>Business Profile</CardTitle>
                    <CardDescription>Manage your salon business information</CardDescription>
                  </div>
                  <Button variant="outline" onClick={() => setIsEditingProfile(true)}>
                    <Edit className="h-4 w-4 mr-2" /> Edit Profile
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="font-medium text-sm text-muted-foreground mb-2">Business Name</h3>
                      <p>{partnerData.businessName}</p>
                    </div>
                    <div>
                      <h3 className="font-medium text-sm text-muted-foreground mb-2">Owner Name</h3>
                      <p>{partnerData.ownerName}</p>
                    </div>
                    <div>
                      <h3 className="font-medium text-sm text-muted-foreground mb-2">Email</h3>
                      <p>{partnerData.email}</p>
                    </div>
                    <div>
                      <h3 className="font-medium text-sm text-muted-foreground mb-2">Phone</h3>
                      <p>{partnerData.phone}</p>
                    </div>
                    <div className="md:col-span-2">
                      <h3 className="font-medium text-sm text-muted-foreground mb-2">Address</h3>
                      <p>{partnerData.address}</p>
                    </div>
                    <div className="md:col-span-2">
                      <h3 className="font-medium text-sm text-muted-foreground mb-2">Business Description</h3>
                      <p>{partnerData.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Edit Profile Dialog */}
              <Dialog open={isEditingProfile} onOpenChange={setIsEditingProfile}>
                <DialogContent className="sm:max-w-[600px]">
                  <DialogHeader>
                    <DialogTitle>Edit Profile</DialogTitle>
                    <DialogDescription>Update your business information below.</DialogDescription>
                  </DialogHeader>
                  <Form {...profileForm}>
                    <form onSubmit={profileForm.handleSubmit(onProfileSubmit)} className="space-y-4">
                      <FormField
                        control={profileForm.control}
                        name="businessName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Business Name</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={profileForm.control}
                        name="ownerName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Owner Name</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={profileForm.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email</FormLabel>
                              <FormControl>
                                <Input {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={profileForm.control}
                          name="phone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Phone</FormLabel>
                              <FormControl>
                                <Input {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={profileForm.control}
                        name="address"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Address</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={profileForm.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Business Description</FormLabel>
                            <FormControl>
                              <Textarea {...field} className="min-h-[100px]" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <DialogFooter>
                        <Button type="button" variant="outline" onClick={() => setIsEditingProfile(false)}>
                          Cancel
                        </Button>
                        <Button type="submit">Save Changes</Button>
                      </DialogFooter>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </TabsContent>

            <TabsContent value="services">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">Your Services</h2>
                <Button onClick={handleAddNewService}>
                  <Plus className="h-4 w-4 mr-2" /> Add Service
                </Button>
              </div>

              <div className="grid gap-4">
                {services.length === 0 ? (
                  <Card>
                    <CardContent className="pt-6 text-center text-muted-foreground">
                      You haven't added any services yet. Click "Add Service" to get started.
                    </CardContent>
                  </Card>
                ) : (
                  services.map((service) => (
                    <Card key={service.id}>
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <CardTitle>{service.name}</CardTitle>
                          <div className="flex space-x-2">
                            <Button size="sm" variant="outline" onClick={() => handleEditService(service)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-red-500 border-red-200 hover:bg-red-50 hover:text-red-600"
                              onClick={() => handleDeleteService(service.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground mb-4">{service.description}</p>
                        <div className="flex space-x-6">
                          <div>
                            <p className="text-sm font-medium">Price</p>
                            <p className="text-lg">${service.price}</p>
                          </div>
                          <div>
                            <p className="text-sm font-medium">Duration</p>
                            <p className="text-lg">{service.duration} min</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>

              {/* Add/Edit Service Dialog */}
              <Dialog open={isAddingService} onOpenChange={setIsAddingService}>
                <DialogContent className="sm:max-w-[500px]">
                  <DialogHeader>
                    <DialogTitle>{editingServiceId !== null ? "Edit Service" : "Add New Service"}</DialogTitle>
                    <DialogDescription>
                      {editingServiceId !== null
                        ? "Update your service information below."
                        : "Fill in the details for your new service."}
                    </DialogDescription>
                  </DialogHeader>
                  <Form {...serviceForm}>
                    <form onSubmit={serviceForm.handleSubmit(onServiceSubmit)} className="space-y-4">
                      <FormField
                        control={serviceForm.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Service Name</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="e.g. Men's Haircut" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={serviceForm.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Description</FormLabel>
                            <FormControl>
                              <Textarea {...field} placeholder="Describe your service" className="min-h-[80px]" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={serviceForm.control}
                          name="price"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Price ($)</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" min="0" step="0.01" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={serviceForm.control}
                          name="duration"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Duration (minutes)</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" min="5" step="5" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <DialogFooter>
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => {
                            setIsAddingService(false)
                            setEditingServiceId(null)
                          }}
                        >
                          Cancel
                        </Button>
                        <Button type="submit">{editingServiceId !== null ? "Update Service" : "Add Service"}</Button>
                      </DialogFooter>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  )
}

