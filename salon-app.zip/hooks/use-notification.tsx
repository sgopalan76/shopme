"use client"

import { useState, useCallback } from "react"

type NotificationType = {
  id: string
  title?: string
  description?: string
  variant?: "default" | "destructive"
}

export function useNotification() {
  const [notifications, setNotifications] = useState<NotificationType[]>([])

  const showNotification = useCallback((notification: Omit<NotificationType, "id">) => {
    const id = Math.random().toString(36).substring(2, 9)
    const newNotification = { ...notification, id }

    setNotifications((prev) => [...prev, newNotification])

    // Auto-dismiss after 5 seconds
    setTimeout(() => {
      dismissNotification(id)
    }, 5000)

    return id
  }, [])

  const dismissNotification = useCallback((id: string) => {
    setNotifications((prev) => prev.filter((notification) => notification.id !== id))
  }, [])

  return {
    notifications,
    showNotification,
    dismissNotification,
  }
}

