"use client"

import type React from "react"
import { createContext, useContext } from "react"
import { Notification } from "@/components/ui/notification"
import { useNotification } from "@/hooks/use-notification"

type NotificationContextType = ReturnType<typeof useNotification>

const NotificationContext = createContext<NotificationContextType | null>(null)

export function NotificationProvider({ children }: { children: React.ReactNode }) {
  const notificationHelpers = useNotification()

  return (
    <NotificationContext.Provider value={notificationHelpers}>
      {children}

      {/* Render notifications */}
      <div className="notification-container">
        {notificationHelpers.notifications.map((notification) => (
          <Notification
            key={notification.id}
            title={notification.title}
            description={notification.description}
            variant={notification.variant}
            onClose={() => notificationHelpers.dismissNotification(notification.id)}
            className="mb-2 animate-in fade-in slide-in-from-right-5 duration-300"
          />
        ))}
      </div>
    </NotificationContext.Provider>
  )
}

export function useNotificationContext() {
  const context = useContext(NotificationContext)
  if (!context) {
    throw new Error("useNotificationContext must be used within a NotificationProvider")
  }
  return context
}

